#pragma once

int add(int x, int y);

