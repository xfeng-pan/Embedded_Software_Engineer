#define _CRT_SECURE_NO_WARNINGS 1

int add(int x, int y)
{
	return x + y;
}

